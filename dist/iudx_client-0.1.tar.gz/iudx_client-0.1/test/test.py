from iudx_client.client import Cat


def main():
    c = Cat("https://catalogue.iudx.org.in/cat/search")
    #print(c.getItemsByTags(["flood alert"], filters=None))
    #l = c.getLatestDataFromItems(c.getItems({"tags":["flood alert"]}, filters=None))
    l = c.getItems(attributes={"tags":["flood alert"]},location={"lat":18.528311,"long":73.874537,"radius":2}, filters=["NAME","id"])
    print(l)

if __name__ == "__main__":
    main()
