from setuptools import setup

setup(name='iudx_client',
      version='0.1',
      description='IUDX catalogue library',
      author='rraks',
      author_email='rakshitadmar@gmail.com  ',
      license='MIT',
      packages=['iudx_client'],
      zip_safe=False)
